#Loading and Fixing the Data Set
#AB_NYC_2019_copy.csv contains cleaned data by removing all observations where price=$0
Airbnb=read.csv("AB_NYC_2019_copy.csv" ,header=T,na.strings="?")
dim(Airbnb)
Airbnb=na.omit(Airbnb)
dim(Airbnb)
View(Airbnb)
attach(Airbnb)

#Install Packages
install.packages("stargazer") 
install.packages("tidyverse",dependencies=TRUE)
install.packages("ggplot2",dependencies=TRUE)
install.packages("dplyr",dependencies=TRUE)
install.packages("knitr",dependencies=TRUE)
install.packages("ISLR")
install.packages("boot")
install.packages("car")

#Libraries
library(stargazer)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(knitr)
library(ISLR)
library(boot)
library(car)
library(tree)
library(randomForest)

#Data Set Exploration (variable names, summary statistics, scatterplot matrix, histograms)
names(Airbnb)
summary(Airbnb)
stargazer(Airbnb,type="text")
pairs(~ price+minimum_nights+
        number_of_reviews+
        reviews_per_month+
        calculated_host_listings_count+
        availability_365,
      Airbnb)

#Frequency Distribution Tables (Understanding the Categorical Variables)
freq_location=data.frame(cbind(Frequency = table(Airbnb$neighbourhood_group), Percent = prop.table(table(Airbnb$neighbourhood_group)) * 100))
freq_location=freq_location[order(freq_location$Frequency),]
freq_location

freq_area=data.frame(cbind(Frequency = table(Airbnb$neighbourhood), Percent = prop.table(table(Airbnb$neighbourhood)) * 100))
freq_area=freq_area[order(freq_area$Frequency),]
freq_area

freq_type=data.frame(cbind(Frequency = table(Airbnb$room_type), Percent = prop.table(table(Airbnb$room_type)) * 100))
freq_type=freq_type[order(freq_type$Frequency),]
freq_type
# Pie charts were produced via Excel for visualization purposes.

# Number of listings by Borough
ggplot(Airbnb, aes(x = fct_infreq(neighbourhood_group), fill = room_type)) +
  geom_bar() +
  labs(title = "Number of listings by borough", x = "Borough", y = "Number of listings") +
  theme(legend.position = "bottom")

# Price density by borough
violin_plot <- ggplot(Airbnb, aes(x = neighbourhood_group, y = price)) +
  geom_violin(trim=FALSE) + ylim(0, 500) + labs(title = "Price densities by Borough", x = "Borough", y = "Price Range") + theme(legend.position = "bottom")
violin_plot + stat_summary(fun.data="mean_sdl", mult=1, geom="pointrange", color='black')

# Number of reviews
ggplot(Airbnb, aes(x = fct_infreq(neighbourhood_group), fill = number_of_reviews)) +
  geom_bar() +
  labs(title = "Number of Reviews by Borough", x = "Borough", y = "Number of reviews") +
  theme(legend.position = "bottom")


#Histogram Visualizations
par(mfrow=c(2,2))
hist(number_of_reviews, col=2, breaks=10)
hist(reviews_per_month, col=2, breaks=10)
hist(calculated_host_listings_count, col=2, breaks=10)
hist(availability_365, col=2, breaks=50)

# train and test data  
set.seed(2)
train=sample(1:nrow(Airbnb),nrow(Airbnb)/2)
test=Airbnb[-train,]
test.price=Airbnb$price[-train]

#Backwards Selection
attach(Airbnb)
library(ISLR)
library(boot)
set.seed(1)
lm.fit1.1 = glm(price~neighbourhood_group+
                  room_type+
                  minimum_nights+
                  number_of_reviews+
                  reviews_per_month+
                  calculated_host_listings_count+
                  availability_365, 
                data=Airbnb)
summary(lm.fit1.1)
set.seed(1)
error=cv.glm(Airbnb,lm.fit1.1, K=10)
error$delta  # error is 34,4464.00

set.seed(1)
lm.fit1.2 = glm(price~neighbourhood_group+
                  room_type+
                  minimum_nights+
                  number_of_reviews+
                  calculated_host_listings_count+
                  availability_365, 
                data=Airbnb)
summary(lm.fit1.2)
error=cv.glm(Airbnb,lm.fit1.2, K=10)
error$delta # error is 34,462.58

set.seed(1)
lm.fit1.3 = glm(price~neighbourhood_group+
                  room_type+
                  minimum_nights+
                  number_of_reviews+
                  availability_365, 
                data=Airbnb) # The final model for multi linear regression
# Obtained using backwards selection 
# - eliminating insignificant variables   
summary(lm.fit1.3)
error=cv.glm(Airbnb,lm.fit1.3, K=10)
error$delta # Final Multiple Regression Model 
stargazer(lm.fit1.1,lm.fit1.2,lm.fit1.3, title="Backwards Selection",type="text",
          align=TRUE, 
          out = "backwards.htm ")

#Diagnostic Plots
par(mfrow=c(2,2))
plot(lm.fit1.3)
par(mfrow=c(1,1))

#Check for Collinearity
install.packages("car")
library(car)
vif(lm.fit1.3)
stargazer(vif(lm.fit1.3), type="text")
#All VIF values are less than 5. 
#This indicates no evidence of problematic amounts of co-linearity. 

#Polynomial Terms
#now we want to find out how many polynomials will reduce cv error
install.packages("ISLR")
library(ISLR)
install.packages("boot")
library(boot)

set.seed(1)
cv.error1=rep(0,3) 
for (i in 1:3){
  glm.fit1 = glm(price~neighbourhood_group+
                   room_type+
                   minimum_nights+
                   availability_365+
                   poly(number_of_reviews,i),data=Airbnb)
  cv.error1[i]=cv.glm(Airbnb,glm.fit1, K=10)$delta[1]
}
cv.error1 # k-fold cv error is lowest at 3rd polynomial for number of reviews

set.seed(1)
cv.error2=rep(0,3) 
for (i in 1:3){
  glm.fit2 = glm(price~neighbourhood_group+
                   room_type+
                   minimum_nights+
                   availability_365+
                   poly(number_of_reviews,3)+ 
                   poly(calculated_host_listings_count,i),
                 data=Airbnb)
  cv.error2[i]=cv.glm(Airbnb,glm.fit2, K=10)$delta[1]
}
cv.error2 # k-fold cv error is lowest at 2nd polynomial for calculated host listings 


set.seed(1)
cv.error3=rep(0,3) 
for (i in 1:3){
  glm.fit3 = glm(price~neighbourhood_group+
                   room_type+
                   minimum_nights+
                   availability_365+
                   poly(number_of_reviews,3)+ 
                   poly(calculated_host_listings_count,2)+
                   poly(reviews_per_month,i),
                 data=Airbnb)
  cv.error3[i]=cv.glm(Airbnb,glm.fit3, K=10)$delta[1]
}
cv.error3 # error is lowest at the 2nd degree 

cv=data.frame("Number of Reviews" = cv.error1, 
              "Calculated Host Listings"=cv.error2,
              "Reviews Per Month" = cv.error3)
stargazer(cv, type="text", out="cv1.htm", summary = FALSE)


lm.fit4=glm(price~room_type+
              neighbourhood_group+
              minimum_nights+
              availability_365+
              poly(number_of_reviews,3)+
              poly(calculated_host_listings_count,2)+
              poly(reviews_per_month,2),
            data=Airbnb)
summary(lm.fit4) 
stargazer(lm.fit4,title="Backwards Selection",type="html",
          align=TRUE, 
          out = "backwards.htm ")


lm.fit5=glm(price~room_type+
              neighbourhood_group+
              minimum_nights+
              availability_365+
              poly(number_of_reviews,3)+
              poly(calculated_host_listings_count,2),
            data=Airbnb)
summary(lm.fit5) 
stargazer(lm.fit5,title="Final Model",type="html",
          align=TRUE, 
          out = "final model.htm ")
error5=cv.glm(Airbnb,lm.fit5, K=10)
error5$delta # with polynomials
error$delta  # error without the polynomials 
# the model with polynomials has the smaller error 


#Regression Decision Tree
Airbnb=read.csv("AB_NYC_2019_copy.csv" ,header=T,na.strings="?")
Airbnb$room_type=as.factor(Airbnb$room_type)
Airbnb$neighbourhood_group =as.factor(Airbnb$neighbourhood_group)
Airbnb=na.omit(Airbnb)
attach(Airbnb)
str(Airbnb)
library(tree)

#test and train data 
set.seed(1)
train=sample(1:nrow(Airbnb),nrow(Airbnb)/2)
test=Airbnb[-train,]
test.price = Airbnb$price[-train]

#tree
tree.Airbnb=tree(price~neighbourhood_group+
                   room_type+
                   minimum_nights+
                   number_of_reviews+
                   reviews_per_month+
                   calculated_host_listings_count+
                   availability_365,
                 data=Airbnb, subset = train)
summary(tree.Airbnb)
plot(tree.Airbnb)
text(tree.Airbnb,pretty=0) # first tree model 

#pruning the tree 
set.seed(1)
c=cv.tree(tree.Airbnb)
l=which.min(c$dev)
c$size[l] # no need to prune in this case 

#prediction and error estimate based on validation set approach 
yhat=predict(tree.Airbnb,newdata=test)
error.tree1 = mean((yhat- test.price)^2)
error.tree1


#bagging
set.seed(1)
Airbnb=read.csv("AB_NYC_2019_copy.csv" ,header=T,na.strings="?")
Airbnb=na.omit(Airbnb)
set.seed(1)
train=sample(1:nrow(Airbnb),nrow(Airbnb)/2)
test=Airbnb[-train,]
test.price = Airbnb$price[-train]
library(tree)
library(randomForest)

tree.bag =randomForest(price~neighbourhood_group+
                         room_type+
                         minimum_nights+
                         number_of_reviews+
                         reviews_per_month+
                         calculated_host_listings_count+
                         availability_365,
                       data=Airbnb,
                       subset=train,
                       mtry=7,
                       importance=TRUE,
                       n.trees = 500 )
tree.bag
importance(tree.bag)
varImpPlot(tree.bag, main = "Bagging: Important Predictors" )
plot(tree.bag)

yhat.bag=predict(tree.bag,newdata=test)
error.tree.bag = mean((yhat.bag-test.price)^2)
error.tree.bag 
error.tree1

#Random Forest
tree.rf =randomForest(price~neighbourhood_group+
                        room_type+
                        minimum_nights+
                        number_of_reviews+
                        reviews_per_month+
                        calculated_host_listings_count+
                        availability_365,
                      data=Airbnb, 
                      subset = train,
                      mtry=7/3,
                      importance=TRUE,
                      n.trees = 500)
plot(tree.bag)

yhat.rf = predict(tree.rf,newdata=test)
error.tree.rf = mean((yhat.rf-test.price)^2)
error.tree.rf
importance(tree.rf)
varImpPlot(tree.rf, main = "Random Forests: Important Predictors")
summary(tree.rf)

error.tree1
error.tree.bag
error.tree.rf


#Logistics Regression
df=data.frame(Airbnb)
High=factor(ifelse(Airbnb$price<=170,"Low","High"))
summary(High)
Airbnb=data.frame(Airbnb,High)
glm.fits=glm(High~latitude+
               longitude+
               number_of_reviews+
               calculated_host_listings_count+
               availability_365,
             data=Airbnb,
             family=binomial)
summary(glm.fits)
glm.probs=predict(glm.fits,type="response") # probability of price being high 
glm.pred=rep("High",38833)
glm.pred[glm.probs<=0.5]="Low"
table(glm.pred,High)
mean(glm.pred==High)
(8892+697)/(8892+647+28597+697)
x=table(glm.pred,High)
stargazer(x,type="text", title = "Confusion Matrix")

set.seed(1)
train=sample(1:nrow(Airbnb),nrow(Airbnb)/2)
High.test=High[-train]
Airbnb.test=Airbnb[-train,]
glm.fits=glm(High~latitude+
               longitude+
               number_of_reviews+
               calculated_host_listings_count+
               availability_365,
             data=Airbnb,family=binomial,subset=train)
glm.probs1=predict(glm.fits,Airbnb.test,type="response")
glm.pred1=rep("Low",19416)
glm.pred1[glm.probs1>0.5]="High"
table(glm.pred1,High.test)
mean(glm.pred1==High.test)
(4558+304)/(4558+303+14251+304)
y=table(glm.pred1,High.test)
stargazer(y,type="text", title = "Confusion Matrix")

